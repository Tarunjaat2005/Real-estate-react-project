export const hostUrl = import.meta.env.VITE_REACT_APP_URL;
