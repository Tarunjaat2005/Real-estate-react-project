import CreateHomeComponent from "../../components/home/CreateHomeComponent"

const CreateHome = () => {
    return <CreateHomeComponent />
}

export default CreateHome