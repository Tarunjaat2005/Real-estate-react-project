import image from '../assets/images/constructor.jpg';

import './Rent.scss';

function Rent() {
    return (
        <div className="page">
            <img src={image} alt="imag" width={400} height={400} />
            <h1>Page is under construction!</h1>
        </div>
    );
}

export default Rent;